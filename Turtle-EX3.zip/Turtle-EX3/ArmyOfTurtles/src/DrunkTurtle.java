
import java.util.Scanner;
import Turtle.Turtle;
import Turtle.*;
import java.util.Random;

public class DrunkTurtle extends Turtle {

	public void moveNormal(double distance) { // help method for the army assignment - act normal
		super.moveForward(distance);
	}

	public void turnLeftNormal(int x) {// help method for the army assignment - act normal
		super.turnLeft(x);
	}

	public void turnRightNormal(int x) {// help method for the army assignment - act normal
		super.turnRight(x);
	}

	public void moveForward(double distance) {
		Random rand = new Random();
		int x = (int) distance;
		int n = rand.nextInt(x); // random distance between 0 and x.
		super.moveForward(n);
		if (new Random().nextDouble() <= 0.45) { // At a 45% probability, it turns x degrees to the left.
			super.turnLeft(x);
		}
		int k = (int) (x * 0.5);
		int y = rand.nextInt(k); // random distance between 0 and 0.5x.
		super.moveForward(y);

	}

	public void turnLeft(int x) { //Turns left like a drunk at a random angle between 0 and 1.5y.
		Random rand = new Random();
		x = (int) (1.5 * x);
		int n = rand.nextInt(x);
		super.turnLeft(n);
	}

	public void turnRight(int x) { //Turns right like a drunk at a random angle between 0 and 1.5y.
		Random rand = new Random();
		x = (int) (1.5 * x);
		int n = rand.nextInt(x);
		super.turnRight(n);
	}

}
