
import java.util.Scanner;
import Turtle.Turtle;
import Turtle.*;
import java.util.Random;

public class JumpyTurtle extends SmartTurtle {
	public void moveNormal(double distance) {  // help method for the army assignment - act normal
		super.moveForward(distance);
	}

	public void moveForward(double distance) { // Leaves a dotted line
		boolean chack = false;
		int i = (int) distance / 5;
		move(i, chack);
	}

	public void move(int i, boolean chack) {
		while (i > 0) {
			if (chack) {
				tailUp();
				super.moveForward(5);
				i--;
				chack = false;
			} else {
				tailDown();
				super.moveForward(5);
				i--;
				chack = true;
			}
		}
	}

}
