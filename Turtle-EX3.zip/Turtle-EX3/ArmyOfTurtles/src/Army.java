

import java.util.Scanner;
import Turtle.Turtle;
import Turtle.*;
import java.util.Random;

public class Army {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose the type of a turtle:");
		System.out.println("1.Simple");
		System.out.println("2.Smart");
		System.out.println("3.Drunk");
		System.out.println("4.Jumpy");
		System.out.println("5.Box");
		System.out.println("6.Grumpy");

		Turtle[] army = new Turtle[5];

		chooseArmy(army);
		tailUpAll(army);
		firstStepRow(army);
		tailDownAll(army);
		thirdStepForward(army);
		StepFourLeft(army);
		fiveStepForward(army);
		StepSixDrawing(army);
		StepSevenHide(army);

	}

	public static void StepSevenHide(Turtle[] army) {
		for (int i = 0; i < 5; i++) {
			army[i].hide();
		}
	}

	public static void fiveStepForward(Turtle[] army) {
		for (int i = 0; i < 5; i++) {
			army[i].moveForward(75);
		}
	}

	public static void StepFourLeft(Turtle[] army) {
		for (int i = 0; i < 5; i++) {
			army[i].turnLeft(40);
		}
	}

	public static void thirdStepForward(Turtle[] army) {
		for (int i = 0; i < 5; i++) {
			army[i].moveForward(65);
		}
	}

	public static void firstStepRow(Turtle[] army) {
		double distance = 480; // Fixed distance between turtles
		for (int i = 0; i < army.length; i++) {
			if (army[i] instanceof DrunkTurtle) {
				// A drunk turtle act normal
				((DrunkTurtle) army[i]).turnRightNormal(90); 
				((DrunkTurtle) army[i]).moveNormal(distance);
				((DrunkTurtle) army[i]).turnLeftNormal(90);
			} else {
				((Turtle) army[i]).turnRight(90);
				//JumpyTurtle act normal
				if (army[i] instanceof JumpyTurtle) {
					((JumpyTurtle) army[i]).moveNormal(distance);
				} else {
					((Turtle) army[i]).moveForward(distance);
				}
				((Turtle) army[i]).turnLeft(90);
			}
			distance = distance - 120;
		}
	}

	public static void StepSixDrawing(Turtle[] army) {
		for (int i = 0; i < army.length; i++) {
			if (army[i] instanceof SmartTurtle) {// If the turtle knows how to draw

				((SmartTurtle) army[i]).draw(6, 40);

			}
		}
	}

	public static void tailDownAll(Turtle[] army) {
		for (int i = 0; i < 5; i++) {
			army[i].tailDown();
		}
	}

	public static void tailUpAll(Turtle[] army) {
		for (int i = 0; i < 5; i++) {
			army[i].tailUp();
		}
	}

	public static void chooseArmy(Turtle[] army) {
		Scanner sc = new Scanner(System.in);
		int counter=0;
		for (int i = 0; i < 5; i++) {
			int choose = sc.nextInt();//User Selection for the Army
			//Open turtles at user's request
			if (choose == 1) {
				Turtle simple = new Turtle();
				army[i] = simple;
			}
			if (choose == 2) {
				SmartTurtle Smart = new SmartTurtle();
				army[i] = Smart;
			}
			if (choose == 3) {
				DrunkTurtle Drunk = new DrunkTurtle();
				army[i] = Drunk;
			}
			if (choose == 4) {
				JumpyTurtle Jumpy = new JumpyTurtle();
				army[i] = Jumpy;
			}
			if (choose == 5) {
				BoxTurtle box = new BoxTurtle();
				army[i] = box;
			}
			if (choose == 6) {
				GrumpyTurtle Grumpy = new GrumpyTurtle();
				army[i] = Grumpy;
			}
			
			counter++;
			if (counter == 5) {
				break;
			}
		}

	}
}
