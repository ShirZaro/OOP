
import java.util.Scanner;
import Turtle.Turtle;
import Turtle.*;

public class SmartTurtle extends Turtle {
	//draw a polygon in the given sides and size
	public void draw(int sides, double size) {
		int x = 180 - (((sides - 2) * 180) / sides); //Finds the angle between the sides
		for (int i = 0; i < sides; i++) {
			tailDown();
			turnRight(x);
			moveForward(size);
		}
	}

}
