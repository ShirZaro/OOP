
import java.util.Scanner;
import Turtle.Turtle;
import Turtle.*;
import java.util.Random;

public class GrumpyTurtle extends DrunkTurtle {
	public void turnRight(int x) {
		super.turnRightNormal(x);
	}

	public void moveForward(double distance) {
		if (new Random().nextDouble() <= 0.5) {
			super.moveForward(distance);
		} else {
			turnRight(180);
		}
	}

}
