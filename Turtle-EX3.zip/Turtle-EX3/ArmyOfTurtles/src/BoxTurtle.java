
import java.util.Random;

public class BoxTurtle extends SmartTurtle {
	public void draw(int sides, double size) {
		int x = 180 - (((sides - 2) * 180) / sides);
		if (new Random().nextDouble() <= 0.4) {
			tailDown();
			rectangle(size); // At a 40% probability, he will draw a rectangle
		} else {
			tailDown();
			Square(size); //At 60% probability, he will draw a square and after draw a polygon in the given sides and size
			turnRight(180);

			for (int i = 0; i < sides; i++) {
				tailDown();
				turnRight(x);
				moveForward(size);
			}
		}
	}

	public void Square(double size) {//draw a square
		int count = 0;
		while (count < 4) {
			moveForward(size);
			turnRight(90);
			count++;
		}
	}

	public void rectangle(double size) {//draw a rectangle
		int count = 0;
		while (count < 2) {
			moveForward(size);
			turnRight(90);
			moveForward(2 * size);
			turnRight(90);
			count++;
		}
	}

}
