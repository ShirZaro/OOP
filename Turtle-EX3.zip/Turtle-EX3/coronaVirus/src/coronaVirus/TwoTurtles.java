package coronaVirus;
import java.util.Scanner;
import Turtle.Turtle;
import Turtle.*;

public class TwoTurtles {

	public static void main(String[] args) {
		Turtle corona = new Turtle();
		Turtle virus = new Turtle();
		corona.tailUp();
		corona.turnLeft(90);
		corona.tailDown();
		corona.moveForward(150);
		corona.turnLeft(90);
		corona.moveForward(150);
		corona.turnLeft(90);
		corona.moveForward(150);
		virus.tailUp();
		virus.turnRight(90);
		virus.moveForward(200);
		virus.tailDown();
		virus.turnRight(120);
		virus.moveForward(170);
		virus.turnRight(120);
		virus.moveForward(170);
	

	}

}
