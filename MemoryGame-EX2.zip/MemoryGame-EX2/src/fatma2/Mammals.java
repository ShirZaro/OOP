package fatma2;

import java.util.Random;

public class Mammals extends Animal {
	public boolean match(Animal a) {
		if ((a instanceof Mammals)) {
			return true;
		} else {
			return false;
		}
	}

}
