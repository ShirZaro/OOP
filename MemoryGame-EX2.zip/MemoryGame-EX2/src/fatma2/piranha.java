package fatma2;

public class piranha extends Fish {
	public piranha() {
		name = "P";
	}

	public boolean match(Animal a) {
		if ((a instanceof piranha)) {
			return true;
		} else {
			return false;

		}
	}

}
