package fatma2;

public class Empty extends Animal {
	public Empty() {
		name = "E";
	}

	public boolean match(Animal a) {// help Animal, after match the Animal at the memory board become Empty
		if ((a instanceof Animal)) {
			return false;
		} else {
			return false;
		}
	}

}
