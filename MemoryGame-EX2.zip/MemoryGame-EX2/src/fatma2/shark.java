package fatma2;

public class shark extends Fish {
	public shark() {
		name = "S";
	}

	public boolean match(Animal a) {
		if ((a instanceof shark)) {
			return true;

		} else {
			return false;
		}
	}

}
