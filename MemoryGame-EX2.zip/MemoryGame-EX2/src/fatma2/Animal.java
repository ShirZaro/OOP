package fatma2;

import java.util.Random;

public class Animal {
	protected String name;
	private String gender;
	private int age;

	public String toString() { // method print for all the Animals
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	public String getGender() {
		return gender;
	}

	public Animal() {
		this.name = name;
		Random rand = new Random(); // gives random age to the animals
		int n = rand.nextInt(100);
		age = n;
		if (new Random().nextDouble() <= 0.5) { // gives random gender to the animal
			String Female = "Female";
			gender = Female;
		} else {
			String male = "male";
			gender = male;

		}
	}

	public boolean match(Animal a) { // checking if the animals match each other
		if ((a instanceof Animal)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean theSame(Animal b) { // checking if the animals are equals
		if (name.equals(b.name)) {

			return true;
		} else
			return false;

	}

}
