package fatma2;

public class lion extends Mammals {
	public  lion(){
		name ="L";
	}
	
	public boolean match(Animal a) {
		if ((a instanceof lion) || (a instanceof Kangaroo)) {
			return true;
		} else {
			return false;

		}

	}
}
