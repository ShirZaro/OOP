package fatma2;

import java.util.Random;

public class Fish extends Animal {
	public boolean match(Animal a) {
		if ((a instanceof Fish)) {
			return true;
		} else {
			return false;
		}
	}

}
