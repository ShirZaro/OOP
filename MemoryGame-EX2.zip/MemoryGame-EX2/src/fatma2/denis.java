package fatma2;

public class denis extends Fish {
	public denis() {
		name = "D";
	}

	public boolean match(Animal a) {
		if ((a instanceof denis)||(a instanceof Kangaroo) ) {
			return true;
		} else {
			return false;

		}
	}

}
