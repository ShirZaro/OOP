package fatma2;

public class turtle extends Reptiles {
	public turtle() {
		name = "T";
	}

	public boolean match(Animal a) {
		if ((a instanceof Reptiles) && !(a instanceof viper)) {
			return true;
		} else {
			return false;
		}
	}

}
