package fatma2;

public class Kangaroo extends Mammals {
	public Kangaroo() {
		name = "K";
	}

	public boolean match(Animal a) { // Joker card
		if ((a instanceof Animal)) {
			return true;
		} else {
			return false;
		}
	}

}
