package fatma2;

public class zebra extends Mammals {

	public zebra() {
		name = "Z";
	}

	public boolean match(Animal a) {
		if ((a instanceof Mammals) && !(a instanceof lion)) {
			return true;
		} else {
			return false;
		}
	}

}
