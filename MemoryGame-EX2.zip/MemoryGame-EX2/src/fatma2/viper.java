package fatma2;

public class viper extends Reptiles {
	public viper() {
		name = "V";
	}

	public boolean match(Animal a) {
		if ((a instanceof viper) || (a instanceof Kangaroo)) {
			return true;
		} else {
			return false;

		}
	}

}
