package fatma2;

import java.util.Random;
import java.util.Scanner;

public class AnimalMemoryGame {

	public static void main(String[] args) {
		String[][] board = new String[5][4]; // starting memory board and # board
		Animal[][] memory = new Animal[5][4];
		Animal[] animal = new Animal[10]; // starting array for the animals
		startGame(board, memory, animal); // starting the game
	}

	public static void startGame(String[][] board, Animal[][] memory, Animal[] animal) { // the main game function
		System.out.print("Welcome to Fatma Memory Game. ");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		newBorad(board, memory, animal); // starting all the boards
		boolean flag1 = true;
		while (notDone(board, memory, flag1, animal)) { // while there is more matches
			int ij = flipcard1(board, memory, flag1); // flip the first card
			int mk = flipcard2(board, memory, flag1);// flip the second card
			if (match(memory, ij, mk)) {
				change(board, ij, mk); // change to *
			} else
				change2(board, ij, mk); // change back to #
		}
	}

	// start game function:
	public static void newBorad(String[][] board, Animal[][] memory, Animal[] animal) {
		startarray(animal);
		startboard(board);
		EmptyMemory(memory);
		startmemory(memory, animal);
		printboard(board);

	}

	public static boolean notDone(String[][] board1, Animal[][] memory1, boolean flag, Animal[] animal) { // two #
		int count = 0;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 4; j++) {
				if ((board1[i][j] == "*")) {
					count++;
					if (count == 18) { // if its the last two cards
						int k = fliplast(board1, memory1);
						int x = k / 100;
						int y = k % 100;
						if (match(memory1, x, y)) {// checking if their match
							printwin();
							finished(board1, memory1, animal);
						} else {
							printlose(); // if the lasr 2 cards not match
							printmemory(memory1);
							finished(board1, memory1, animal);
						}
						return false;
					}
				}
			}
		}
		if (!yesmatch(memory1)) { // if their is no more matches and more than 2 cards
			printmemory(memory1);
			printlose();
			finished(board1, memory1, animal);
			return false;
		}
		return true;

	}

	public static boolean yesmatch(Animal[][] memory1) { // checking if there are more matches
		for (int k = 0; k < 5; k++) {
			for (int l = 0; l < 4; l++) {
				for (int i = 0; i < 5; i++) {
					for (int j = 0; j < 4; j++) {
						if (memory1[i][j] instanceof Empty) { // if the animal is empty- continue
							continue;
						}
						if (k != i || l != j) {
							if (memory1[k][l].match(memory1[i][j])) { // if there is match- return true
								return true;
							}
						}
					}

				}
			}
		}
		return false;
	}

	public static int flipcard1(String[][] board1, Animal[][] memory1, boolean flag) {
		if (flag) {
			print1();
		}
		Scanner sc = new Scanner(System.in);// getting the coordinate from the user
		String str = sc.nextLine();
		if (legal(str, flag)) {
			int i = (int) str.charAt(0) - 48; // remove the char into int
			int j = (int) str.charAt(1) - 48;
			if (check(board1, i, j, flag)) { // check if the place is legal
				board1[i][j] = memory1[i][j].getName(); // remove the Animal from the numbers matrix to the board
				for (int k = 0; k < 5; k++) { // printing the new board
					if (k != 0) {
						System.out.println();
					}
					for (int l = 0; l < 4; l++) {
						System.out.print(board1[k][l] + " ");
					}
				}

				int ij = i * 10 + j;
				return ij;
			} else {
				flag = false; // if the coordinate are wrong, try again
				return flipcard1(board1, memory1, flag);
			}
		} else {
			flag = false; // if the coordinate are wrong, try again
			return flipcard1(board1, memory1, flag);
		}
	}

	public static int flipcard2(String[][] board1, Animal[][] memory1, boolean flag) { // fliping the second card
		if (flag) {
			print2();
		}
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		if (legal(str, flag)) {
			int m = (int) str.charAt(0) - 48;
			int g = (int) str.charAt(1) - 48;
			if (check(board1, m, g, flag)) {
				board1[m][g] = memory1[m][g].getName();
				for (int k = 0; k < 5; k++) {
					if (k != 0) {
						System.out.println();
					}
					for (int l = 0; l < 4; l++) {
						System.out.print(board1[k][l] + " ");

					}
				}

				int mg = m * 10 + g;
				return mg;
			} else {
				flag = false; // if the coordinate are wrong, try again
				return flipcard1(board1, memory1, flag);
			}
		} else {
			flag = false;
			return flipcard2(board1, memory1, flag);
		}
	}

	public static int fliplast(String[][] board1, Animal[][] memory1) { // checking if the last two cards are match
		int ij = 0;
		int mk = 0;

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 4; j++) {
				if (!(memory1[i][j] instanceof Empty)) { // if the place is not empty, save the coordinates
					ij = i * 10 + j;
				}
			}
		}
		int m = 0;
		int k = 0;
		for (m = 0; m < 5; m++) {
			if (m == ij / 10 && k == ij % 10)
				continue;
			for (k = 0; k < 4; k++) {
				if (m == ij / 10 && k == ij % 10)
					continue;
				if (!(memory1[m][k] instanceof Empty)) { // if the place is not empty, save the coordinates
					mk = m * 10 + k;
				}
			}
		}
		int mikom = ij * 100 + mk;
		return mikom;
	}

	public static void finished(String[][] board1, Animal[][] memory1, Animal[] animal) {
		// checking if the user want to play again
		System.out.print("Would you like to start a new game? ");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		boolean done = true;
		if (str.charAt(0) == 'y' || str.charAt(0) == 'Y') {
			startGame(board1, memory1, animal);
		}
		if (str.charAt(0) == 'n' || str.charAt(0) == 'N') {
			done = false;
			while (done == false) {
				break;
			}

		} else {
			printeror();
			finished(board1, memory1, animal);
		}

	}

	public static boolean check(String[][] board2, int k, int g, boolean flag) {
		// help function - checking if the coordinate legal
		if ((k > 4) || (g > 3)) {
			printeror();
			flag = false;
			return false;
		}

		if ((board2[k][g] != "#")) {
			printeror();
			flag = false;
			return false;

		} else {
			flag = true;
			return true;

		}
	}

	public static boolean legal(String str, boolean flag) {

		if (((str.charAt(0) < 48) || (str.charAt(0) > 52)) && ((str.charAt(1) < 48) || (str.charAt(1) > 52))) {
			printeror();
			flag = false;
			return false;
		}

		if (str.length() != 2) {
			printeror();
			flag = false;
			return false;
		}

		return true;

	}

	public static boolean match(Animal[][] memory, int x, int y) { // checking if the cards are match
		int a = x / 10;
		int b = x % 10;
		int k = y / 10;
		int j = y % 10;
		Empty e = new Empty();

		if (((memory[a][b] instanceof shark) && (memory[k][j] instanceof piranha))
				|| ((memory[a][b] instanceof piranha) && (memory[k][j] instanceof shark))) {
			// if one of the animals is Shark and the other Piranha, we need to check if
			// their
			// is Denis next to one of them
			if (nextdenis(memory, a, b)) {
				System.out.println("\n" + "Cards do not match!");
				return false;
			}
			if (nextdenis(memory, k, j)) {
				System.out.println("\n" + "Cards do not match!");
				return false;
			}
			if (!nextdenis(memory, k, j)) {
				System.out.println("\n" + "Cards match!");
				memory[a][b] = e; // if the cards match - the place become empty
				memory[k][j] = e;
				return true;
			}
			if (nextdenis(memory, a, b)) {
				System.out.println("\n" + "Cards match!");
				memory[a][b] = e;
				memory[k][j] = e;
				return true;
			}
		}
		if ((memory[a][b]).match(memory[k][j])) { // checking if the animals are match
			System.out.println("\n" + "Cards match!");
			memory[a][b] = e;
			memory[k][j] = e;
			return true;
		} else {
			System.out.println("\n" + "Cards do not match!");
			return false;
		}
	}

	public static boolean nextdenis(Animal arr[][], int x, int y) {
		// checking if there is Denis next to the Shark or Piranha
		try {
			if (arr[x + 1][y] instanceof denis)
				return true;

		} catch (Exception e) {
		}
		try {
			if (arr[x][y + 1] instanceof denis)
				return true;

		} catch (Exception e) {
		}
		try {
			if (arr[x - 1][y] instanceof denis)
				return true;

		} catch (Exception e) {
		}
		try {
			if (arr[x][y - 1] instanceof denis)
				return true;

		} catch (Exception e) {
		}

		return false;
	}

	// print function
	public static void print1() {
		System.out.println("\n" + "Please choose first card to flip");
	}

	public static void print2() {
		System.out.println("\n" + "Please choose second card to flip ");
	}

	public static void printeror() {
		System.out.println("Sorry, wrong input. Please try again.");
	}

	public static void printwin() {
		System.out.println("\n" + "Game is over! All cards are matched");
	}

	public static void printlose() {
		System.out.println("\n" + "Game is over! No more possible matches.");
	}

	public static void printboard(String[][] boardA) {
		System.out.println();
		for (int i = 0; i < 5; i++) {
			if (i != 0) {
				System.out.println();
			}
			for (int j = 0; j < 4; j++) {
				System.out.print(boardA[i][j] + " ");
			}

		}
		System.out.println();

	}

	public static void printmemory(Animal a[][]) {
		for (int i = 0; i < 5; i++) {
			if (i != 0) {
				System.out.println();
			}
			for (int j = 0; j < 4; j++) {
				if (a[i][j] instanceof Empty) {
					System.out.print("# ");
				} else
					System.out.print(a[i][j].getName() + " ");
			}

		}
	}

	public static void change(String[][] board1, int i, int j) { // change into * if cards match
		board1[i / 10][i % 10] = "*";
		board1[j / 10][j % 10] = "*";
		printboard(board1);
	}

	public static void change2(String[][] board1, int i, int j) {// change back to # if cards not match
		board1[i / 10][i % 10] = "#";
		board1[j / 10][j % 10] = "#";
		printboard(board1);
	}

	// start game function:
	public static void startarray(Animal animal[]) {
		monkey M = new monkey();
		zebra Z = new zebra();
		lion L = new lion();
		Kangaroo K = new Kangaroo();
		viper V = new viper();
		iguana I = new iguana();
		turtle T = new turtle();
		shark S = new shark();
		piranha P = new piranha();
		denis D = new denis();
		animal[0] = M;
		animal[1] = Z;
		animal[2] = L;
		animal[3] = K;
		animal[4] = V;
		animal[5] = I;
		animal[6] = T;
		animal[7] = S;
		animal[8] = P;
		animal[9] = D;
	}

	public static void startboard(String arr[][]) {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 4; j++) {
				arr[i][j] = "#";
			}
		}
	}

	public static void EmptyMemory(Animal[][] arr) {
		Empty e = new Empty();
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 4; j++) {
				arr[i][j] = e;
			}
		}
	}

	public static void startmemory(Animal animal[][], Animal arr1[]) {
		for (int i = 0; i < arr1.length; i++) {
			putanimal(animal, arr1, i);
		}
		for (int i = 0; i < arr1.length; i++) {
			putanimal(animal, arr1, i);
		}

	}

	public static void putanimal(Animal arr[][], Animal a[], int i) {
		Random rand = new Random(); // put the animals at random place
		int x = rand.nextInt(5);
		int y = rand.nextInt(4);
		if (!(next(arr, a, i, x, y)) && (arr[x][y] instanceof Empty)) {
			// Checking if the place is empty and legal
			arr[x][y] = a[i];
		} else {
			putanimal(arr, a, i); // if the place is taken or not legal- try again
		}
	}

	public static boolean next(Animal arr[][], Animal a[], int i, int x, int y) {
		// when we start the memory board, we need to check if their is 2 animals that
		// are the same next to each other.
		try {
			if ((arr[x + 1][y] == a[i]) && (!(arr[x + 1][y] instanceof Empty) && (arr[x][y] instanceof Empty)))
				return true;

		} catch (Exception e) {
		}
		try {
			if ((arr[x][y + 1] == a[i]) && (!(arr[x][y + 1] instanceof Empty) && (arr[x][y] instanceof Empty)))
				return true;

		} catch (Exception e) {
		}
		try {
			if ((arr[x - 1][y] == a[i]) && (!(arr[x - 1][y] instanceof Empty) && (arr[x][y] instanceof Empty)))
				return true;

		} catch (Exception e) {
		}
		try {
			if ((arr[x][y - 1] == a[i]) && (!(arr[x][y - 1] instanceof Empty) && (arr[x][y] instanceof Empty)))
				return true;

		} catch (Exception e) {
		}

		return false;
	}

}
