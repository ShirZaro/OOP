package fatma2;

public class iguana extends Reptiles {
	public iguana() {
		name = "I";
	}

	public boolean match(Animal a) {
		if ((a instanceof Reptiles) && !(a instanceof viper)) {
			return true;
		} else {
			return false;
		}
	}

}
