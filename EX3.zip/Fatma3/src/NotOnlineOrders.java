public class NotOnlineOrders extends Orders  {

	
	protected int EmployeeID;

	
	
	
	public int getEmployeeID() {
		return EmployeeID;
	}
	
	
	public NotOnlineOrders (int EventID,int customerID,int EmployeeID,int numberOfTickets) {
		super(EventID, customerID, EmployeeID, numberOfTickets);
		this.EmployeeID = EmployeeID;
	}
	
	public static void main(String[] args) {

	}

}