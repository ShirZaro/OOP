public class Onlineorders extends Orders  {

	protected String URL;

	
	public Onlineorders (int a, int b, int c ,String URL) {
		super(a,b,c ,URL);
		this.URL = URL;
	}
	
	public static void main(String[] args) {

	}

}