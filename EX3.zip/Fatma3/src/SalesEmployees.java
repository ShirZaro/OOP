import java.util.Vector;

 public class SalesEmployees extends Employees{
	private static Vector <Events>  Events= new Vector <Events>();
	private static Vector <NotOnlineOrders>  NotOnlineOrders= new Vector <NotOnlineOrders>();

	
	
	private String EmployeeID ;
	private double NumberOfTickets ;
	private int PricePerTicket;
	protected double FinalSalary;
	protected double BonusRateForSale ;
	
	public double getBonusRateForSale () {
		return BonusRateForSale;
	}
	
	

	public SalesEmployees(int ID, String name, int age, double BonusRateForSale) {
		super (name, age, ID);
		this.BonusRateForSale = BonusRateForSale;
	}

	
	public void Salery(Vector <NotOnlineOrders> notOnline,Vector <Events>  Event , Vector <Customers> Customer  ) {
		for ( int i = 0; i< notOnline.size(); i++ ) {
			if (notOnline.get(i).getEmployeeID() == this.ID) {// ����� 2 ��� �� �� ���� ������ ����� ���
				int IDcus = notOnline.get(i).getcustomerID();
				int IDev = notOnline.get(i).getEventID();
				int numT= notOnline.get(i).getNumberOfTickets();
				whatPrice(IDcus , IDev, Event  , numT);// ����� �� �� ����� �������� ����
			}
		}
		
	}


	public void whatPrice(int iDcus,int iDev, Vector<Events> event, int numT) {
		for ( int i = 0; i< event.size(); i++ ) {   
			if (event.get(i).getID() == iDev) {
				double price= event.get(i).getPricePerTicket();
			calaul (price, numT);
			}
		}
		
	}

	public void calaul(double price, double numT) {
		 FinalSalary = FinalSalary + (numT* price * BonusRateForSale);
	}



	
	

}