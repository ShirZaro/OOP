import java.util.Vector;

 public class Orders  implements Gradeble {

	private int count ;
	private static Vector <Employees> Employees=new Vector <Employees>();
	private static Vector <Customers>  Customers= new Vector <Customers>();
	private static Vector <Events>  Events= new Vector <Events>();
	private int EventID;
	private int customerID;
	private int NumberOfTickets;
	private int ID;
	

	
	
	public int getEventID() {
		return EventID;
	}
	public int getcustomerID() {
		return customerID;
	}
	
	public int getNumberOfTickets() {
		return NumberOfTickets;
	}
	
	
	public Orders(int EventID, int customerID, int numberOfTickets, String URL) {
		this.EventID = EventID;
		this.NumberOfTickets = numberOfTickets;
		this.customerID = customerID;
	}

	public Orders(int EventID,int customerID,int EmployeeID,int numberOfTickets) {
		this.EventID = EventID;
		this.customerID = customerID;
		this.NumberOfTickets = numberOfTickets;
	
	}
	
	public double getGrade() {
			for (int i = 0; i < Events.size();i ++) {
				if ( this.EventID == Events.get(i).getID()) {
					double count = this.NumberOfTickets * Events.get(i).getGrade();
				}
			}
			
		
		return count;
	}
 }
	