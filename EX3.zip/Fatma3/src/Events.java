import java.io.IOException;
import java.util.Vector;
public class Events implements Gradeble<Double> ,Comparable<Events> {

		private int Price;
		private int ID;
		private String Name ;
		private int PricePerTicket;
		private int numT;
		private static Vector <Orders> Orders=new Vector <Orders>();
		private static Vector <Employees> Employees=new Vector <Employees>();
		private static Vector <Customers>  Customers= new Vector <Customers>();
		
	public Events (int sidornum, String name, int price ) throws NegativePriceException {
		this.ID = ID;
		this.Name = Name;
		if ( PricePerTicket < 0 ) {
			throw new NegativePriceException();
		}
		else
			this.PricePerTicket = PricePerTicket;
	}
	
	public int getID() {
		return ID;
	}
	
	public String toString() {
		return "Name:"+ Name;
	}
	public String getName() {
		return Name;
	}
	
	public int getPricePerTicket() {
		return PricePerTicket;
	}

	
	
	public int SumT() {
			for ( int i = 0 ; i < Orders.size() ; i ++) {
				if (this.ID == Orders.get(i).getEventID()) {
					numT = numT+ Orders.get(i).getNumberOfTickets();
				}
			}	
		return numT;
	}

	

	public int compareTo(Events A) {
		if (this.numT<A.numT)
			return -1;
		if (this.numT>A.numT)
			return 1;
		return 0;
	}


	public double getGrade() {
		double Price = this.PricePerTicket;
		return Price;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


}