
public interface Gradeble <T>{

	
	public double getGrade();
}
