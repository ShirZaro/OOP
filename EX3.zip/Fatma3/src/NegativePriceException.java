public class NegativePriceException extends Exception {
		public NegativePriceException () {
			super("Negative Price Exception");
		}

	}