 class Employees  implements Gradeble, Comparable<Employees> {

	
	protected int ID;
	protected String Name ;
	protected int Age;
	protected double Salary;
	

	public Employees(String name2, int age2, int EmployeeID) {
	this.Age=age2;
	this.Name=name2;
	this.ID = EmployeeID;
	}
	public Employees(int iD, String name, int age) {
		this.ID=iD;
		this.Name=name;
		this.Age=age;

		
 }

	public double getSalary() {
		return Salary;
	}
	public int getID() {
		return ID;
	}
	public String getName() {
		return Name;
	}

	public int getAge() {
		return Age;
	}
	
	
	public String toString() {
		return "Name:"+ Name +" ; "+"age:" +Age;
	}
	
	public int compareTo(Employees A) {
		if (this.Salary<A.Salary)
			return -1;
		if (this.Salary>A.Salary)
			return 1;
		return 0;
		
	}
	
	public double getGrade() {
		
		return Salary;
	}
	
	
	
	
}
