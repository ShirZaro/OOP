import java.util.Vector;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Comparator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
	public class Salesoffice {
		
		
		private static Vector <NotOnlineOrders> NotOnlineOrders = new Vector<NotOnlineOrders>();
		private static Vector <Onlineorders> Onlineorders = new Vector<Onlineorders>();
		private static Vector <Orders> Orders = new Vector<Orders>();
		public static Vector <Events> Events = new Vector<Events>();
		private static Vector <Employees> Employees = new Vector<Employees>();
		private static Vector <SalesEmployees> SalesEmployees = new Vector<SalesEmployees>();
		private static Vector <MarketingEmployees> MarketingEmployees = new Vector<MarketingEmployees>();
		private static Vector <Customers> Customers = new Vector<Customers>();

	
		public Salesoffice (String fileEvents, String fileEmployees, String fileCustomers , String fileTicketsSales) throws GENDERException,NegativePriceException{
			// ������� ��� ������
			readEvents (fileEvents);
			readOrders (fileTicketsSales);
			readEmployees (fileEmployees);
			readCustomer(fileCustomers);
			}
		
		public  void printAgeReport(int eventID) { //������� ����� ������
			String  NameEvent = "";
			int numT=0; // ���� ������� ��� ��� ����� ����
			for (int i = 0; i< Events.size(); i++) {
				if (Events.get(i).getID()== eventID) {
			     NameEvent = Events.get(i).getName();
					break;
				}
			}
			for (int i = 0; i< Orders.size(); i++) {
				if (Orders.get(i).getEventID()== eventID) {
					numT += Orders.get(i).getNumberOfTickets();
					int IDcus = Orders.get(i).getcustomerID();
					howold ( IDcus , numT, NameEvent); //����� ��� 
				}
			}
			}

	public void howold(int iDcus, int numT, String NameEvent) {
		// �������� ��� � 2
			int age0_18 = 0;
			int age19_24 = 0;
			int age25_35 = 0;
			int age36_50 = 0;
			int age51_70 = 0;
			for ( int i = 0; i< Customers.size(); i ++ ) {
				if ( Customers.get(i).getID()== iDcus) {
					if (( 0 <= Customers.get(i).getAge()) && (Customers.get(i).getAge() < 19 )) {
						age0_18 ++;
					}
					if (( 19 <= Customers.get(i).getAge()) && (Customers.get(i).getAge() < 25 )) {
						age19_24 ++;
					}
					if (( 25 <= Customers.get(i).getAge()) && (Customers.get(i).getAge() < 36 )) {
						age25_35 ++;
					}
					if (( 36 <= Customers.get(i).getAge()) && (Customers.get(i).getAge() < 51 )) {
						age36_50 ++;
					}
					if (( 51 <= Customers.get(i).getAge()) && (Customers.get(i).getAge() < 71)) {
						age51_70 ++;
					}
				}
			}
           printEvent (age0_18, age19_24, age25_35 , age36_50, age51_70, NameEvent,numT);
			
			
		}

	public void printEvent(int age0_18, int age19_24, int age25_35, int age36_50, int age51_70, String NameEvent, int numT) {
	// �������� ����� � 2 
		System.out.println("Event name:"+ NameEvent );
		System.out.println("0-18: " + ((age0_18*100)/numT) + "%");
		System.out.println("19-24: " + ((age19_24*100)/numT) + "%");
		System.out.println("25-35: " + ((age25_35*100)/numT) + "%");
		System.out.println("36-50: " + ((age36_50*100)/numT) + "%");
		System.out.println("51-70: " + ((age51_70*100)/numT) + "%");

	}

	public double getOnlineProportion() { // ������� ������
		double calculate =(Onlineorders.size() / Orders.size()) ;
		return calculate;
	}
	
	public double getBalance() { // ������� ������
		double Total =0;
		double TotalIn =+ TotalIN();
		double TotalOut =+ TotalOut();
		Total = (TotalIn - TotalOut) ;
		return Total;
	}
	
	public void firmReport() { //������� 5 
		
		System.out.println("SalesOffice report:");
		System.out.println("Employees list:");
		bubelSort(Employees);
		Employees.toString();
		//������ �����
		System.out.println("Event list:");
		bubelSort(Events);
		Events.toString();
		//+������ �����
		System.out.println("Customer list:");
		bubelSort(Customers);
		Customers.toString();
		//������ �����+
	}
	
	
	 public static <Object extends Comparable <Object>> Object getMax(Vector <? extends Comparable <Object>> max) {//������� 6 
			 bubelSort(max);
			 Object Max=  (Object) max.get(0);
		     return Max;
	 }
	 
	 public static  <Object extends  Gradeble<Double>> double getAvgValue(Vector<? extends Gradeble <Object>> avg) { //������� 7
		 double calcul = AVG(avg) / avg.size();
		 return calcul;
		
		 
		 }
		 
		 
		private static  double Count;
	public static <Object extends  Gradeble> double AVG(Vector<? extends Gradeble <Object>> avg) {// ��� � 7 
		for ( int i = 0; i < avg.size() ; i ++ ) {
			double Count =+  avg.get(i).getGrade() ;
		}
		return Count;
	}

	public static <Object extends Comparable <Object>> void bubelSort(Vector<? extends Comparable <Object>> sort)  { // ���� ����� ������ ����
		for (int i =0; i < sort.size() - 1; i ++ ) {
			for ( int j = 0; j< sort.size()- i - 1 ; j++) {
			if ((((Comparable) sort.get(i)).compareTo(sort.get(i+1)))<0 ) {
				swap (sort, i , i +1);
			}
		}
		}
	}

	public static <Object> void swap(Vector<Object> save , int i, int j) { //����� ������ 
		Object S  =  save.get(i);
		Object L = save.get(j);
		save.remove(i);
		save.add(i ,  L );
		save.remove(i);
		save.add(j,  S );
	}
	
	

	public double TotalOut() {// ��� ������ 
		double TotalOut1 = 0;
		double TotalOut2 =0;
		for ( int i = 0; i < SalesEmployees.size() ; i ++ ) {
			TotalOut1 = TotalOut1 +SalesEmployees.get(i).FinalSalary;
		}
		for ( int i = 0; i < MarketingEmployees.size() ; i ++ ) {
			TotalOut2 = TotalOut2 +MarketingEmployees.get(i).FinalSalary;
		}
		
		double TotalOut = TotalOut1 +TotalOut2;
		
		return TotalOut;
	}

	private double TotalIN() {
		int numT,Price,Idev = 0;
		double TotalIn =0;
		for(int i = 0; i < Events.size(); i ++) {
			 Idev= Events.get(i).getID();
			 Price = Events.get(i).getPricePerTicket();
			 numT= FindNumT(Idev);
			 TotalIn = TotalIn + calcul (Price,numT);
		}
		return TotalIn;	
		
	}

	private int calcul( int price, int numT) {
	int sum=( price*numT);
		return sum;
	}

	private int FindNumT(int idev) {
		int numT= 0;
		for (int i = 0 ; i < Orders.size(); i ++ ) {
			if (Orders.get(i).getEventID() == idev ) {
				numT = numT + Orders.get(i).getNumberOfTickets();
			}
		}
		return numT;
	}

	private static Vector<String> readFile(String file) { // ����� ����
		Vector<String> lines = new Vector<String>(); // ���� �� ������
		BufferedReader inFile = null;
		FileReader fr = null;
		try {
			fr = new FileReader(file);
			inFile = new BufferedReader(fr);
			String line = inFile.readLine(); // ����� ���� �����
			while ((line = inFile.readLine()) != null) {
				lines.add(line); // ����� �� ���� ��� �����
			}
			return new Vector<String>(lines); // ����� �����
		} catch (IOException e) {
			System.out.println("The file " + file + " was not found.");
			return null;
		} finally {
			try {
				inFile.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	private void readCustomer (String File) throws GENDERException {
		Vector <String> lines = readFile(File);
		String name= "";
		int ID = 0;
		int age= 0;
		String gender = "";
		int EmployeeID = 0;
		int length = lines.size();
		for ( int i =0; i < length ; i++) {
			String[]costumer= lines.get(i).split("\t");
			ID = Integer.parseInt(costumer[0]);
			name= costumer[1];
			age =Integer.parseInt(costumer[2]);
			gender = costumer[3];
			EmployeeID =Integer.parseInt(costumer[4]);
			Customers.add(new Customers(ID , name, age, gender , EmployeeID));
			
			
		}
	}
	
	
	private void readEmployees (String file)  {
		Vector <String> lines = readFile(file);
		int ID = 0;
		String Name= "";
		int Age= 0;
		double BonusRateForSale = 0;
		int Phone = 0;
		int length = lines.size();
		for ( int i =0; i < length ; i++) {
			String[]Employees= lines.get(i).split("\t");
			ID = Integer.parseInt(Employees[0]);
			Name= Employees[1];
			Age =Integer.parseInt(Employees[2]);
			BonusRateForSale = Double.parseDouble(Employees[3]);
			Phone =Integer.parseInt(Employees[4]);
			if ( BonusRateForSale != 0 ) {
				SalesEmployees.add(new SalesEmployees( ID ,Name, Age , BonusRateForSale));
			}
				else {
					MarketingEmployees.add(new MarketingEmployees(ID, Name, Age, Phone));
				}
			}
			
		}
	
	
	private static void readEvents (String file) throws NegativePriceException  {
		Vector <String> lines = readFile(file);
		String Name= "";
		int ID = 0;
		int PricePerTicket= 0;
		int length = lines.size();
		for ( int i =0; i < length ; i++) {
			String[]Event= lines.get(i).split("\t");
			Name= Event[0];
			ID = Integer.parseInt(Event[1]);
			PricePerTicket =Integer.parseInt(Event[2]);
			Events.add (new Events (ID , Name, PricePerTicket));
			System.out.println(Events.get(i));
			
		}
	}
	
	private void readOrders (String file)  {
		Vector <String> lines = readFile(file);
		int EventID = 0;
		int customerID= 0;
		int EmployeeID= 0;
		int numberOfTickets = 0;
		String URL = "";
		int length = lines.size();
		for ( int i =0; i < length ; i++) {
			String[]Orders= lines.get(i).split("\t");
			EventID = Integer.parseInt(Orders[0]);
			customerID = Integer.parseInt(Orders[1]);
			EmployeeID = Integer.parseInt(Orders[2]);
			numberOfTickets = Integer.parseInt(Orders[3]);
			if ( Orders.length > 4 ) {
			URL= Orders[4];
			Onlineorders.add(new Onlineorders(EventID, customerID, numberOfTickets, URL)); 

			} else { 
				NotOnlineOrders.add(new NotOnlineOrders(EventID, customerID, EmployeeID, numberOfTickets));
			}
			
		}
	}

	
	
	public static void main(String[] args)  {

		 try {
			Salesoffice sl = new Salesoffice ( "Events.txt", "Employees.txt", "Customers.txt","Orders.txt");
		} catch (GENDERException e) {
			
			e.printStackTrace();
		} catch (NegativePriceException e) {
			
			e.printStackTrace();
		}
		 for ( int i = 0; i< Events.size(); i++) {
			 System.out.println(Events.get(i));
		 }
		 
		 
		 }
		/*String path = "Events.txt";

		try {
			
			String content = Files.readString(Paths.get(path));
			System.out.println(content);

		} catch (IOException e) {
			e.printStackTrace();
		}
		readEvents(path);
	*/
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
