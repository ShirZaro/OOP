import java.util.Vector;

public class Customers implements Gradeble , Comparable<Customers> {
		
		private  int IDevent ;
		private  int Tickets;
		private  int price ;
		private int ID;
		private String Name ;
		private String Gender;
		private int Age;
		private int EmployeeID; 
		public int numT;
		private static Vector <Orders>  Orders= new Vector <Orders>();
		private static Vector <Events>  Events= new Vector <Events>();
		
		
		
	public Customers ( int ID, String Name,  int Age ,String Gender,int EmployeeID ) throws GENDERException {
		this.ID = ID;
		this.Name = Name;
		this.Age = Age;
		if ((Gender != "f") && (Gender != "m") && (Gender != "F") && (Gender != "M")) {
			throw new GENDERException();
		}
		else {
			this.Gender = Gender;
		}
		this.EmployeeID = EmployeeID;
	}
	
	public String toString() {
		return "Name:"+ Name +" ; "+"age:" +Age+" ; "+ "Gender:"+ Gender;
	}
	
	
	public int getID() {
		return ID;
	}
	public String getName() {
		return Name;
	}
	public String getGender() {
		return Gender;
	}
	public int getAge() {
		return Age;
	}
	public int getEmployeeID() {
		return EmployeeID ;
	}


	public double getGrade() {
		int IDev = FindIDev();
		int Tickets = findnum(IDev);
		int Price = FindPrice(IDev);
		int count = price*Tickets;
		return count;
	}
	
	
	public int FindIDev() {
		for ( int i = 0; i < Orders.size(); i ++ ) {
			if ( Orders.get(i).getcustomerID() == this.ID) {
				int IDevent = Orders.get(i).getEventID();
				
			}
		}
		
		return IDevent;
	}
	
	
	
	public int FindPrice(int IDev2) {
		for ( int i = 0; i < Events.size(); i ++ ) {
			if ( Events.get(i).getID()== IDev2) {
				int price = Events.get(i).getPricePerTicket();
				
			}
		}
		
		return price;
	}

	
	
	public int  findnum(int IDev3) {
		for(int i = 0 ; i < Orders.size(); i ++ ) {
				if (Orders.get(i).getEventID() == IDev3) {
					int Tickets = Orders.get(i).getNumberOfTickets();
				}
		}
		return Tickets;
	}
	
	public int getnumT() {// ����� �� �� ������ ������� �� ���� ������
			for ( int j = 0 ; j < Orders.size() ; j ++) {
				if (this.ID==Orders.get(j).getcustomerID()) {
					numT = numT+ Orders.get(j).getNumberOfTickets();
				}
		}
		return numT;
	}

	
	public int compareTo(Customers o) {
		if (this.numT<o.numT)
			return -1;
		if (this.numT>o.numT)
			return 1;
		return 0;
	}

	

	
	
	

	
	
}
	
	
	
	