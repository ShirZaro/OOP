public class GENDERException extends Exception {
	public GENDERException () {
		super("Illegal gender");
	}

}
